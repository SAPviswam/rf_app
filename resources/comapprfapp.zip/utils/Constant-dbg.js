sap.ui.define(
    [],
    function() {
      "use strict";
  
      
     return {
        oAccountSID:"AC2fb46ec1c11689b5cecea6361105c723",
        oAuthToken:"da7a3a92efa2e8b11389b7795e13b47c",
        oServiceID:"VA5066e1e13fdbec992bd1aa4ca908f479"
     }
    }
  );
  