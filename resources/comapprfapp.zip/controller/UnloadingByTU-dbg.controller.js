sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/Device",
	"sap/ui/model/json/JSONModel",
	"sap/m/Popover",
	"sap/m/Button",
	"sap/m/library"
],
function (Controller,Device,JSONModel,Popover,Button,library) {
    "use strict";

    return Controller.extend("com.app.rfapp.controller.UnloadingByTU", {
        onInit: function () {
            const oTable = this.getView().byId("idTable_UBYTU");
            oTable.attachBrowserEvent("dblclick", this.onRowDoubleClick.bind(this));
			
        },
        onRowDoubleClick: function () {
            debugger
            var oSelected = this.byId("idTable_UBYTU").getSelectedItem();
            // var ID = oSelected.getBindingContext().getObject()
            this.getView().byId("page1_UBYTU").setVisible(false);
            this.getView().byId("page2_UBYTU").setVisible(true);
        },
       
        Onpressback0: function () {
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("Supervisor");
        },
        Onpresssubmit: function () {

            this.getView().byId("page1_UBYTU").setVisible(true);
            // this.getView().byId("page2Shipment_UBYTU").setVisible(true);
             this.getView().byId("page2_UBYTU").setVisible(false);
             this.getView().byId("idTable_UBYTU").setVisible(true);
             this.getView().byId("idPanel_UBYTU").setVisible(true);
           

        },
       
        Onpressback1: function () {

            this.getView().byId("page1_UBYTU").setVisible(true);
            this.getView().byId("page2_UBYTU").setVisible(false);
          


            

        },
        onHUListPress:function () {

            this.getView().byId("page1_UBYTU").setVisible(false);
            this.getView().byId("page2_UBYTU").setVisible(false);
            this.getView().byId("page3_UBYTU").setVisible(true);
           
         
        },
        Onpressback2:function(){
            
            this.getView().byId("page1_UBYTU").setVisible(false);
            this.getView().byId("page2_UBYTU").setVisible(true);
            this.getView().byId("page3_UBYTU").setVisible(false);
           
            
            
        },
        onNewHUPress:function(){
            this.getView().byId("page1_UBYTU").setVisible(false);
            this.getView().byId("page2_UBYTU").setVisible(false);
            this.getView().byId("page3_UBYTU").setVisible(false);
           
            this.getView().byId("page4_UBYTU").setVisible(true);
            this.getView().byId("page5_UBYTU").setVisible(false);

         
        },
        Onpressback3:function(){
            this.getView().byId("page1_UBYTU").setVisible(false);
            this.getView().byId("page2_UBYTU").setVisible(true);
            this.getView().byId("page4_UBYTU").setVisible(false);
           
        },
        onNextEnterpress:function(){
            this.getView().byId("page5_UBYTU").setVisible(true);
           
            this.getView().byId("page4_UBYTU").setVisible(false);
           
            this.getView().byId("page1_UBYTU").setVisible(false);
            this.getView().byId("page2_UBYTU").setVisible(false);

            
        },
        Onpressback4:function(){
            this.getView().byId("page1_UBYTU").setVisible(false);
            this.getView().byId("page5_UBYTU").setVisible(false);
           
            this.getView().byId("page4_UBYTU").setVisible(true);
            this.getView().byId("page3_UBYTU").setVisible(false);

         
        
            this.getView().byId("page2_UBYTU").setVisible(false);

            
        },
        onGRPress:function(){
            this.getView().byId("page6_UBYTU").setVisible(true);
            this.getView().byId("page5_UBYTU").setVisible(false);
            this.getView().byId("page4_UBYTU").setVisible(false);
           

            this.getView().byId("page1_UBYTU").setVisible(false);
            this.getView().byId("page2_UBYTU").setVisible(false);


        },
        Onpressback5:function(){
            this.getView().byId("page1_UBYTU").setVisible(false);
            this.getView().byId("page5_UBYTU").setVisible(true);
            this.getView().byId("page6_UBYTU").setVisible(false);
            
           
            this.getView().byId("page4_UBYTU").setVisible(false);
          

        
            this.getView().byId("page2_UBYTU").setVisible(false);

            
        },
        onUnloadPress:function(){
            this.getView().byId("page6_UBYTU").setVisible(false);
            this.getView().byId("page5_UBYTU").setVisible(false);
            this.getView().byId("page4_UBYTU").setVisible(false);
            this.getView().byId("page7_UBYTU").setVisible(true);

           
            this.getView().byId("page1_UBYTU").setVisible(false);
            this.getView().byId("page2_UBYTU").setVisible(false);


        },

       
        // onUnloadPress1:function(){
        //     this.getView().byId("page6_UBYTU").setVisible(false);
        //     this.getView().byId("page5_UBYTU").setVisible(false);
        //     this.getView().byId("page4_UBYTU").setVisible(false);
        //     this.getView().byId("page7_UBYTU").setVisible(true);

        //     this.getView().byId("_IDGenButton4444").setVisible(false); 
        //     this.getView().byId("_IDGenButton2222").setVisible(false);
        //     this.getView().byId("_IDGenButton3333").setVisible(false);  
        //     this.getView().byId("_IDGenButton1111").setVisible(false);
        //     this.getView().byId("_IDGenButton5555").setVisible(false);
        //     this.getView().byId("_IDGenButton6666").setVisible(false);
           


        //     this.getView().byId("page1_UBYTU").setVisible(false);
        //     this.getView().byId("page2_UBYTU").setVisible(false);


        // },
        Onpressback6:function(){
            this.getView().byId("page1_UBYTU").setVisible(false);
            this.getView().byId("page5_UBYTU").setVisible(true);
            this.getView().byId("icon7").setVisible(false);
            this.getView().byId("page6_UBYTU").setVisible(false);
           
            this.getView().byId("page3_UBYTU").setVisible(false);
         
            this.getView().byId("page4_UBYTU").setVisible(false);

        
            this.getView().byId("page2_UBYTU").setVisible(false);

            
        },
        // Onpressback7:function(){
        //     this.getView().byId("page1_UBYTU").setVisible(false);
        //     this.getView().byId("page5_UBYTU").setVisible(true);
        //     this.getView().byId("page6_UBYTU").setVisible(false);
        //     this.getView().byId("page7_UBYTU").setVisible(false);

           
        //     this.getView().byId("page3_UBYTU").setVisible(false);
        //     this.getView().byId("_IDGenButton4444").setVisible(false); 
        //     this.getView().byId("_IDGenButton2222").setVisible(false);
        //     this.getView().byId("_IDGenButton3333").setVisible(false);  
        //     this.getView().byId("_IDGenButton1111").setVisible(false);
        //     this.getView().byId("_IDGenButton5555").setVisible(false);
        //     this.getView().byId("_IDGenButton6666").setVisible(false);
      
        //     this.getView().byId("page4_UBYTU").setVisible(false);

        
        //     this.getView().byId("page2_UBYTU").setVisible(false);

            
        // },

    });
});